-- MySQL dump 10.13  Distrib 5.1.73, for unknown-linux-gnu (x86_64)
--
-- Host: localhost    Database: mattconk_little_research
-- ------------------------------------------------------
-- Server version	5.1.73-cll

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `blogs`
--

DROP TABLE IF EXISTS `blogs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blogs` (
  `auto` int(11) NOT NULL AUTO_INCREMENT,
  `blog_name` varchar(250) NOT NULL,
  `blog_link` varchar(250) NOT NULL,
  PRIMARY KEY (`auto`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blogs`
--

LOCK TABLES `blogs` WRITE;
/*!40000 ALTER TABLE `blogs` DISABLE KEYS */;
INSERT INTO `blogs` (`auto`, `blog_name`, `blog_link`) VALUES (1,'Mashable','http://mashable.com/'),(2,'John Polacek','http://johnpolacek.github.com/'),(3,'Brad Frost','http://bradfrostweb.com/'),(4,'treehouse blog','http://blog.teamtreehouse.com/category/make-a-website'),(5,'a list apart','http://www.alistapart.com/'),(6,'hongkiat.com','http://www.hongkiat.com/blog/tag/rwd/'),(8,'UIE brainsparks','http://www.uie.com/brainsparks/'),(12,'htmll5 rocks','http://www.html5rocks.com/en/'),(13,'design shack','http://designshack.net/'),(14,'astonish design','http://www.astonishdesign.com/blog#.UP6gWydEF8E'),(15,'webdesigner depot','http://www.webdesignerdepot.com/'),(16,'luke w','http://www.lukew.com/'),(17,'smashing magazine (mobile)','http://mobile.smashingmagazine.com/'),(18,'singlemind','http://singlemindconsulting.com/blog'),(19,'mobile awesomeness','http://www.mobileawesomeness.com/blog/'),(20,'chris mills','http://dev.opera.com/author/chrismills');
/*!40000 ALTER TABLE `blogs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `posts`
--

DROP TABLE IF EXISTS `posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `posts` (
  `auto` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(250) NOT NULL,
  `author` varchar(100) DEFAULT NULL,
  `author_link` varchar(250) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `intro` varchar(1000) NOT NULL,
  `article_link` varchar(250) NOT NULL,
  `added` date NOT NULL,
  PRIMARY KEY (`auto`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `posts`
--

LOCK TABLES `posts` WRITE;
/*!40000 ALTER TABLE `posts` DISABLE KEYS */;
INSERT INTO `posts` (`auto`, `title`, `author`, `author_link`, `date`, `intro`, `article_link`, `added`) VALUES (1,'Why 2013 Is the Year of Responsive Web Design','Pete Cashmore','http://mashable.com/about/','2012-12-11','For those of us who create websites and services, a million screens have bloomed, and we need to build for all of them.','http://mashable.com/2012/12/11/responsive-web-design/','2013-01-19'),(2,'This is Responsive','Brad Frost','http://bradfrostweb.com/',NULL,'Patterns, resources and news for creating responsive web experiences.','http://bradfrost.github.com/this-is-responsive/','2013-01-19'),(3,'What The Heck Is Responsive Web Design?','John Polacek','http://johnpolacek.github.com/',NULL,'Introductory presentation to Responsive Web Design. (using Scolldeck plugin)','http://johnpolacek.github.com/scrolldeck.js/decks/responsive/','2013-01-19'),(4,'Beginner’s Guide to Responsive Web Design','Nick Pettit','http://blog.teamtreehouse.com/author/nickpettit','2012-08-08','Whether you’re a beginner or a seasoned web professional, creating responsive designs can be confusing at first, mostly because of the radical change in thinking that’s required. As time goes on, responsive web design is drifting away from the pool   Read more: You searched for Beginner’s Guide to Responsive Web Design','http://blog.teamtreehouse.com/beginners-guide-to-responsive-web-design','2013-01-19'),(5,'Responsive Web Design','Ethan Marcotte','http://www.alistapart.com/authors/m/emarcotte','2010-05-25','Designers have coveted print for its precision layouts, lamenting the varying user contexts on the web that compromise their designs. Ethan Marcotte advocates we shift our design thinking to appropriate these constraints: using fluid grids, flexible images, and media queries, he shows us how to embrace the “ebb and flow of things” with responsive web design.','http://www.alistapart.com/articles/responsive-web-design/','2013-01-19'),(7,'Responsive Web Design Guidelines and Tutorials','Smashing Editorial','http://www.smashingmagazine.com/author/admin/','2012-07-02','In this overview you will find the most useful and popular articles we have published on Smashing Magazine on Responsive Web Design.','http://www.smashingmagazine.com/responsive-web-design-guidelines-tutorials/','2013-01-19'),(8,'Where are the Mobile First Responsive Web Designs?','JASON GRISBY','http://blog.cloudfour.com/author/jason-grigsby/','2012-09-11','Instead of starting with a desktop site, you start with the mobile site and then progressively enhance to devices with larger screens. As a bonus, you benefit from the advantages of Mobile First design that Luke Wroblewski espouses.','http://www.uie.com/articles/mobile_first_rwd/','2013-01-20'),(9,'The Many Faces of ‘Mobile First’','Brad Frost','http://bradfrostweb.com/','2012-08-13','The rise of mobile has already reshaped the world, opened up new dimensions of interaction and forced us to rethink how we create digital products. It’s incredible, and it’s just the beginning. As ‘mobile first’ continues to pervade even more aspects of culture and design, it’s only a matter of time before it becomes the default mode of thinking. ','http://bradfrostweb.com/blog/mobile/the-many-faces-of-mobile-first/','2013-01-20'),(17,'CREATING A MOBILE-FIRST RESPONSIVE WEB DESIGN','Brad Frost','http://www.html5rocks.com/en/profiles/#bradfrost','2012-04-16','As the web landscape becomes increasingly complex, it\'s becoming extremely important to deliver solid web experiences to a growing number of contexts. Thankfully, responsive web design gives web creators some tools for making layouts that respond to any screen size. We\'ll use fluid grids, flexible images and media queries to get the layout looking great regardless of the size of the device\'s screen dimensions.','http://www.html5rocks.com/en/mobile/responsivedesign/','2013-01-22'),(18,'Mobile First Design: Why It’s Great and Why It Sucks','Joshua Johnson','http://designshack.net/author/joshuajohnson/','2012-03-13','Historically, most web designers and their clients have approached the desktop side of any project first, while leaving the mobile part as a secondary goal that gets accomplished later. Even with the rise of responsive design, many of us begin with the “full size” site and work our way down.','http://designshack.net/articles/css/mobilefirst/','2013-01-22'),(19,'Some notes about mobile first web design','Nick Comito','http://www.astonishdesign.com/about-us/our-team/nick-comito#.UP6gHidEF8E','2012-12-10','If you are a small business owner and have recently been looking for a web application, a new website, a mobile app, or almost anything else on the internet you may have come across terms like responsive web design (RWD), adaptive web design, fluid grids, etc. Another term that is quite popular is \'mobile first\' and I\'ll be writing a bit about what it means, its advantages, and how agencies like us are using it on our projects.','http://www.astonishdesign.com/blog/some-notes-about-mobile-first-web-design#.UP6gEidEF8F','2013-01-22'),(20,'Find the right words for your mobile… first','Marli Mesibov','https://twitter.com/marsinthestars','2012-04-28','As designers we focus on creating with the user in mind, and that means paying attention to the user’s mobile. This need to keep mobile in mind has lead Luke Wroblewski and many others to tout the phrase “Mobile First,” meaning that the mobile experience should be designed and considered first and foremost with desktops a secondary consideration.','http://www.webdesignerdepot.com/2012/08/find-the-right-words-for-your-mobile-first/','2013-01-22'),(21,'Mobile First','Luke Wroblewski','http://www.lukew.com/about','2009-11-03','More often than not, the mobile experience for a Web application or site is designed and built after the PC version is complete. Here\'s three reasons why Web applications should be designed for mobile first instead.','http://www.lukew.com/ff/entry.asp?933','2013-01-22'),(22,'Responsibly responsive. Mobile First Responsive Design. Part 1',NULL,NULL,NULL,'It’s no secret the web has become ubiquitous. It’s on our computers, phones, game consoles, TVs or even home appliances. With such diversity, came new challenges. How do you design for old, new and yet to come devices, how do you adapt to the variety of screen sizes, capabilities and control inputs? Surely, old “fixed-width-desktop-only” approaches will not work, and there’s a need for a shift in paradigm of how sites should be designed and implemented','http://www.cognifide.com/blogs/mobile/responsibly-responsive-mobile-first-responsive-design-part-1/','2013-01-22'),(23,'Separate Mobile Website Vs. Responsive Website','Brad Frost','http://mobile.smashingmagazine.com/author/brad-frost/?rel=author','2012-08-22','The US presidential race is heading into full swing, which means we’ll soon see the candidates intensely debate the country’s hot-button issues. While the candidates are busy battling it out, the Web design world is entrenched in its own debate about how to address the mobile Web: creating separate mobile websites versus creating responsive websites.','http://mobile.smashingmagazine.com/2012/08/22/separate-mobile-responsive-website-presidential-smackdown/','2013-01-22'),(24,'Mobile Site vs. Responsive Design: Head-to-Head Comparison of Cost, UX & SEO',' Cort Buchholz','http://singlemindconsulting.com/blog/cort-buchholz','2012-12-05','The mobile app vs. mobile site debate has recently expanded to include responsive design. Responsive web design adapts the site layout to the viewing environment. Page elements get resized, repositioned, or hidden as browser resolution changes.','http://singlemindconsulting.com/blog/cort-buchholz/mobile-site-vs-responsive-design-head-head-comparison-cost-ux-seo','2013-01-22'),(25,'Responsive Design vs Mobile Site: The Benefits and Drawbacks','Brian Middleton','http://planetargon.com/who-we-are/brian-middleton','2012-05-01','When planning your mobile website strategy, you will want to\r\nask yourself a few questions. Do you want your mobile site\r\nto operate separately from your current website? Would it be\r\nbetter, if you are starting from scratch, to build a site that could\r\nact as both a mobile and a desktop site? Can your current site\r\nbe retrofitted to be more mobile friendly?','http://planetargon.com/assets/Planet_Argon-Responsive_Design_vs_Mobile_Site.pdf','2013-01-22'),(26,'2012 into 2013: web standards in perspective','Chris Mills','http://dev.opera.com/author/chrismills','2013-01-23','2012 has been a very exciting year for web standards and web development: we saw the emergence of some very powerful graphic and layout specs, which served to bring the web closer to the ability of traditional desktop applications and desktop publishing programs; we saw application enablers like web components and device hardware access drastically increase the available scope of what we can control using JavaScript; we were greeted by some interesting debates and scandals; and much, much more!','http://www.netmagazine.com/features/2012-2013-web-standards-perspective','2013-01-23'),(27,'Getting Started With Twitter Bootstrap','Thoriq Firdaus','http://www.hongkiat.com/blog/author/thoriq/','2013-01-23','Building a website from the ground up is very hard. Even some people who are able to code in web languages like JavaScript, HTML and CSS would find difficulties in the process. Fortunately, a few Twitter developers and designers are aware of this situation and had launched a framework called Bootstrap to make life easier for web designers and developers.','http://www.hongkiat.com/blog/twitter-bootstrap/','2013-01-23');
/*!40000 ALTER TABLE `posts` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2014-03-10 14:08:45
